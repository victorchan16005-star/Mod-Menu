package com.modmenu.configuration

import android.content.Context
import android.content.SharedPreferences
import com.modmenu.core.FeatureConfig

/** Position stored as fractions of the free screen area, so it survives rotation and other screen sizes. */
data class MenuPosition(val xFraction: Float, val yFraction: Float)

class ConfigStore(context: Context) {
    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("modmenu_config", Context.MODE_PRIVATE)

    fun getMenuPosition(gameId: String): MenuPosition = MenuPosition(
        prefs.getFloat("pos.$gameId.x", 1f),
        prefs.getFloat("pos.$gameId.y", 0.35f)
    )

    fun setMenuPosition(gameId: String, p: MenuPosition) {
        prefs.edit()
            .putFloat("pos.$gameId.x", p.xFraction.coerceIn(0f, 1f))
            .putFloat("pos.$gameId.y", p.yFraction.coerceIn(0f, 1f))
            .apply()
    }

    fun getPackageOverride(gameId: String): String? =
        prefs.getString("pkg.$gameId", null)?.takeIf { it.isNotBlank() }

    fun setPackageOverride(gameId: String, packageName: String?) {
        prefs.edit().apply {
            if (packageName.isNullOrBlank()) remove("pkg.$gameId") else putString("pkg.$gameId", packageName.trim())
        }.apply()
    }

    fun forFeature(gameId: String, featureId: String): FeatureConfig =
        PrefsFeatureConfig(prefs, "feat.$gameId.$featureId.")
}

private class PrefsFeatureConfig(
    private val prefs: SharedPreferences,
    private val prefix: String
) : FeatureConfig {
    override fun getBoolean(key: String, default: Boolean): Boolean = prefs.getBoolean(prefix + key, default)
    override fun putBoolean(key: String, value: Boolean) { prefs.edit().putBoolean(prefix + key, value).apply() }
    override fun getInt(key: String, default: Int): Int = prefs.getInt(prefix + key, default)
    override fun putInt(key: String, value: Int) { prefs.edit().putInt(prefix + key, value).apply() }
    override fun getString(key: String, default: String?): String? = prefs.getString(prefix + key, default)
    override fun putString(key: String, value: String?) { prefs.edit().putString(prefix + key, value).apply() }
}
