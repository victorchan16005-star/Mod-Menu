package com.modmenu.games.superbearadventure

import com.modmenu.core.Feature
import com.modmenu.core.GameModule
import com.modmenu.core.GameProfile
import com.modmenu.features.SharedFeatures

object SuperBearAdventureModule : GameModule {
    override val profile = GameProfile(
        id = "superbearadventure",
        displayName = "Super Bear Adventure",
        description = "3D platformer by Earthkwak Games.",
        knownPackages = listOf("com.Earthkwak.Platformer")
    )

    // Game-specific features go here ONLY after being verified on a real install.
    // None are verified yet, so none are listed.
    private fun gameFeatures(): List<Feature> = emptyList()

    override fun createFeatures(): List<Feature> = SharedFeatures.standard() + gameFeatures()
}
