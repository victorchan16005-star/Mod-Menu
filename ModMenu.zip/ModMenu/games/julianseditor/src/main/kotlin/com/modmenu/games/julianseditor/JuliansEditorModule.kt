package com.modmenu.games.julianseditor

import com.modmenu.core.Feature
import com.modmenu.core.GameModule
import com.modmenu.core.GameProfile
import com.modmenu.features.SharedFeatures

object JuliansEditorModule : GameModule {
    override val profile = GameProfile(
        id = "julianseditor",
        displayName = "Julian's Editor",
        description = "Game-creation app by Hortor Interactive.",
        // First is the Google Play id I found. The second is listed by a third-party site as the
        // newer "Builda" app and is NOT verified. The scanner reports whichever is installed.
        knownPackages = listOf("com.hortor.julianseditor", "com.hortor.juliancysj")
    )

    // Game-specific features go here ONLY after being verified on a real install.
    // None are verified yet, so none are listed.
    private fun gameFeatures(): List<Feature> = emptyList()

    override fun createFeatures(): List<Feature> = SharedFeatures.standard() + gameFeatures()
}
