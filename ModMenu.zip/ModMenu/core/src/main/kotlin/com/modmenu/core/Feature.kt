package com.modmenu.core

import android.content.Context

enum class FeatureCategory(val title: String) {
    PLAYER("Player"),
    WORLD("World"),
    ADVANCED("Advanced"),
    COMPATIBILITY("Compatibility"),
    MENU("Menu")
}

enum class FeatureKind { TOGGLE, ACTION }

sealed class Compatibility {
    object Supported : Compatibility()
    /** Known not to work here. */
    data class Unsupported(val reason: String) : Compatibility()
    /** Not tested/verified against this game build, so it stays disabled. */
    data class Unverified(val reason: String) : Compatibility()
}

sealed class FeatureResult {
    data class Ok(val message: String? = null) : FeatureResult()
    data class Failed(val message: String) : FeatureResult()
}

/** Per-feature key/value storage, scoped to (game, feature). */
interface FeatureConfig {
    fun getBoolean(key: String, default: Boolean): Boolean
    fun putBoolean(key: String, value: Boolean)
    fun getInt(key: String, default: Int): Int
    fun putInt(key: String, value: Int)
    fun getString(key: String, default: String?): String?
    fun putString(key: String, value: String?)
}

/** What the menu hands to a feature. */
interface FeatureEnvironment {
    val context: Context
    val profile: GameProfile
    val report: GameReport
    fun configFor(feature: Feature): FeatureConfig
    fun requestRescan()
}

interface Feature {
    val id: String
    val title: String
    val description: String
    val category: FeatureCategory
    val kind: FeatureKind
    val defaultEnabled: Boolean get() = false

    /** Must be honest: return Supported only for combinations that were actually verified. */
    fun checkCompatibility(env: FeatureEnvironment): Compatibility

    fun onToggle(env: FeatureEnvironment, enabled: Boolean): FeatureResult =
        FeatureResult.Failed("This feature is not a toggle")

    fun onAction(env: FeatureEnvironment): FeatureResult =
        FeatureResult.Failed("This feature is not an action")
}

/** One module per game. Modules must not depend on each other. */
interface GameModule {
    val profile: GameProfile
    fun createFeatures(): List<Feature>
}

object GameRegistry {
    private val modules = LinkedHashMap<String, GameModule>()
    fun register(module: GameModule) { modules[module.profile.id] = module }
    fun all(): List<GameModule> = modules.values.toList()
    fun get(id: String): GameModule? = modules[id]
}
