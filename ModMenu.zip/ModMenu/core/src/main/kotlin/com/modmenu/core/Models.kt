package com.modmenu.core

/** Config key under which a toggle feature's on/off state is stored. */
const val CONFIG_KEY_ENABLED = "enabled"

/** Ids and defaults of the built-in menu settings (shared by features and the overlay). */
object MenuSettings {
    const val AUTO_COLLAPSE = "menu.auto_collapse"
    const val SNAP_TO_EDGE = "menu.snap_to_edge"
    const val AUTO_COLLAPSE_DEFAULT = false
    const val SNAP_TO_EDGE_DEFAULT = true
    const val AUTO_COLLAPSE_DELAY_MS = 6000L
}

enum class ScriptingBackend(val label: String) {
    IL2CPP("IL2CPP"),
    MONO("Mono"),
    UNKNOWN("backend unknown"),
    NOT_UNITY("not Unity")
}

/** Static description of a supported game. Contains package names only, never versions. */
data class GameProfile(
    val id: String,
    val displayName: String,
    val description: String,
    /** Package names to look for, in priority order. */
    val knownPackages: List<String>
)

/** What the compatibility scanner found on this device for one game. */
data class GameReport(
    val profile: GameProfile,
    val installed: Boolean,
    val packageName: String? = null,
    val versionName: String? = null,
    val versionCode: Long = 0L,
    val apkAbis: List<String> = emptyList(),
    val deviceAbis: List<String> = emptyList(),
    /** null = could not be determined. */
    val isUnity: Boolean? = null,
    val backend: ScriptingBackend = ScriptingBackend.UNKNOWN,
    val unityVersion: String? = null,
    val apkCount: Int = 0,
    val warnings: List<String> = emptyList()
) {
    val backendKnown: Boolean
        get() = backend == ScriptingBackend.IL2CPP || backend == ScriptingBackend.MONO

    fun summaryLine(): String {
        if (!installed) return "Not installed"
        return buildString {
            append(versionName ?: "unknown version")
            append(" · ")
            when (isUnity) {
                true -> append("Unity ").append(unityVersion ?: "(version not found)")
                false -> append("not a Unity build")
                null -> append("engine unknown")
            }
            if (isUnity == true) append(" · ").append(backend.label)
        }
    }

    fun toText(): String = buildString {
        appendLine("Game: ${profile.displayName}")
        appendLine("Installed: $installed")
        if (installed) {
            appendLine("Package: $packageName")
            appendLine("Version: $versionName ($versionCode)")
            appendLine("Unity: ${when (isUnity) { true -> "yes, ${unityVersion ?: "version not found"}"; false -> "no"; null -> "unknown" }}")
            appendLine("Scripting backend: ${backend.label}")
            appendLine("APK native ABIs: ${apkAbis.joinToString().ifEmpty { "none found" }}")
            appendLine("APK files scanned: $apkCount")
        }
        appendLine("Device ABIs: ${deviceAbis.joinToString()}")
        warnings.forEach { appendLine("Warning: $it") }
    }.trimEnd()
}
