# No reflection is used; modules are referenced directly. Add keep rules here
# only if a future module loads classes by name.
