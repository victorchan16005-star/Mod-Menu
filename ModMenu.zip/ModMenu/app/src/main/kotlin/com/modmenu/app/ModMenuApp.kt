package com.modmenu.app

import android.app.Application
import com.modmenu.core.GameRegistry
import com.modmenu.games.julianseditor.JuliansEditorModule
import com.modmenu.games.superbearadventure.SuperBearAdventureModule

/** The only place that knows about both game modules. */
class ModMenuApp : Application() {
    override fun onCreate() {
        super.onCreate()
        GameRegistry.register(JuliansEditorModule)
        GameRegistry.register(SuperBearAdventureModule)
    }
}
