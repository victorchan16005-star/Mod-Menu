package com.modmenu.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.modmenu.compatibility.GameInspector
import com.modmenu.configuration.ConfigStore
import com.modmenu.core.GameModule
import com.modmenu.core.GameRegistry
import com.modmenu.core.GameReport
import com.modmenu.floatingmenu.OverlayService
import com.modmenu.resources.R

/** Game selection screen. Each card starts the shared floating menu for one game. */
class MainActivity : Activity() {
    private lateinit var config: ConfigStore
    private lateinit var inspector: GameInspector
    private lateinit var cards: LinearLayout
    private var awaitingOverlayFor: String? = null
    private var notificationFor: String? = null
    private var askedNotification = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        config = ConfigStore(this)
        inspector = GameInspector(this)

        val column = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(c(R.color.mm_bg))
            isFillViewport = true
            addView(column)
        }
        ViewCompat.setOnApplyWindowInsetsListener(scroll) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            column.setPadding(dp(20) + b.left, dp(24) + b.top, dp(20) + b.right, dp(24) + b.bottom)
            insets
        }
        column.setPadding(dp(20), dp(24), dp(20), dp(24))

        column.addView(text("Mod Menu", 28f, c(R.color.mm_text), bold = true))
        column.addView(text("Choose a game", 14f, c(R.color.mm_text_dim)).apply { setPadding(0, dp(2), 0, dp(16)) })
        cards = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        column.addView(cards)
        column.addView(
            text(
                "This build only scans installed games and shows the floating menu. No game-modifying features are " +
                    "offered: none have been verified yet.",
                12f, c(R.color.mm_text_dim)
            ).apply { setPadding(dp(4), dp(8), dp(4), 0) }
        )
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        val pending = awaitingOverlayFor
        awaitingOverlayFor = null
        if (pending != null && Settings.canDrawOverlays(this)) startMenu(pending)
        refresh()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        // A denied notification permission only hides the notification; the menu still works.
        val game = notificationFor
        notificationFor = null
        if (game != null) startMenu(game)
    }

    // ------------------------------------------------------------------ rendering

    private fun refresh() {
        val modules = GameRegistry.all()
        Thread {
            val reports = modules.associate { it.profile.id to safeInspect(it) }
            runOnUiThread { if (!isDestroyed) render(modules, reports) }
        }.start()
    }

    private fun safeInspect(m: GameModule): GameReport = try {
        inspector.inspect(m.profile, config.getPackageOverride(m.profile.id))
    } catch (t: Throwable) {
        GameReport(m.profile, installed = false, warnings = listOf("Scan failed: ${t.message ?: t.javaClass.simpleName}"))
    }

    private fun render(modules: List<GameModule>, reports: Map<String, GameReport>) {
        cards.removeAllViews()
        for (m in modules) {
            val r = reports[m.profile.id] ?: continue
            val statusColor = when {
                !r.installed -> c(R.color.mm_error)
                r.backendKnown -> c(R.color.mm_ok)
                else -> c(R.color.mm_warn)
            }
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(c(R.color.mm_surface), 18, c(R.color.mm_purple_dim))
                setPadding(dp(16), dp(16), dp(16), dp(16))
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(14) }
            }
            card.addView(text(m.profile.displayName, 20f, c(R.color.mm_text), bold = true))
            card.addView(text(m.profile.description, 12f, c(R.color.mm_text_dim)))
            card.addView(text(r.summaryLine(), 13f, statusColor).apply { setPadding(0, dp(10), 0, 0) })
            r.warnings.take(3).forEach {
                card.addView(text("• $it", 11f, c(R.color.mm_warn)).apply { setPadding(0, dp(4), 0, 0) })
            }

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(0, dp(14), 0, 0)
            }
            row.addView(button("Show menu", primary = true, enabled = r.installed) { startMenu(m.profile.id) }, weight())
            row.addView(button("Launch", primary = false, enabled = r.installed) { launchGame(r) }, weight())
            row.addView(button("Package…", primary = false, enabled = true) { editPackage(m) }, weight())
            card.addView(row)
            cards.addView(card)
        }
    }

    // ------------------------------------------------------------------ actions

    private fun startMenu(gameId: String) {
        if (!Settings.canDrawOverlays(this)) {
            awaitingOverlayFor = gameId
            toast("Allow “Display over other apps” for Mod Menu, then come back.")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && !askedNotification &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotification = true
            notificationFor = gameId
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
            return
        }
        OverlayService.start(this, gameId)
        toast("Menu started. Look for the round “M” button.")
    }

    private fun launchGame(report: GameReport) {
        val pkg = report.packageName ?: return
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) toast("Could not find a launch screen for $pkg") else startActivity(intent)
    }

    private fun editPackage(m: GameModule) {
        val input = EditText(this).apply {
            setText(config.getPackageOverride(m.profile.id) ?: "")
            hint = m.profile.knownPackages.firstOrNull() ?: "com.example.game"
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("${m.profile.displayName} package")
            .setMessage("Leave empty to auto-detect from the known package names.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                config.setPackageOverride(m.profile.id, input.text.toString().trim().ifEmpty { null })
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ------------------------------------------------------------------ view helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun c(id: Int): Int = getColor(id)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()

    private fun text(s: String, sp: Float, color: Int, bold: Boolean = false): TextView = TextView(this).apply {
        text = s
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(color: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun weight() = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
        marginEnd = dp(6)
    }

    private fun button(label: String, primary: Boolean, enabled: Boolean, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            setAllCaps(false)
            setTextColor(Color.WHITE)
            isEnabled = enabled
            alpha = if (enabled) 1f else 0.4f
            stateListAnimator = null
            background = if (primary) {
                GradientDrawable(
                    GradientDrawable.Orientation.LEFT_RIGHT,
                    intArrayOf(c(R.color.mm_purple), c(R.color.mm_blue))
                ).apply { cornerRadius = dp(12).toFloat() }
            } else {
                rounded(c(R.color.mm_surface_alt), 12)
            }
            setOnClickListener { onClick() }
        }

    private companion object {
        const val REQ_NOTIFICATIONS = 42
    }
}
