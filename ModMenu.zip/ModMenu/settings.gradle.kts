pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "ModMenu"
include(":app", ":core", ":compatibility", ":configuration", ":floatingmenu", ":features", ":resources")
include(":games:julianseditor", ":games:superbearadventure")
