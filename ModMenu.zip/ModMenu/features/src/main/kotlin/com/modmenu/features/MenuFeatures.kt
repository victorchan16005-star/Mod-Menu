package com.modmenu.features

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import com.modmenu.core.Compatibility
import com.modmenu.core.Feature
import com.modmenu.core.FeatureCategory
import com.modmenu.core.FeatureEnvironment
import com.modmenu.core.FeatureKind
import com.modmenu.core.FeatureResult
import com.modmenu.core.MenuSettings

/** Collapses the panel after a few seconds without touches. The overlay reads the stored state. */
class AutoCollapseFeature : Feature {
    override val id = MenuSettings.AUTO_COLLAPSE
    override val title = "Auto-collapse"
    override val description = "Hide the panel after 6 seconds without touching it."
    override val category = FeatureCategory.MENU
    override val kind = FeatureKind.TOGGLE
    override val defaultEnabled = MenuSettings.AUTO_COLLAPSE_DEFAULT
    override fun checkCompatibility(env: FeatureEnvironment): Compatibility = Compatibility.Supported
    override fun onToggle(env: FeatureEnvironment, enabled: Boolean): FeatureResult = FeatureResult.Ok()
}

/** Snaps the floating button to the nearest screen edge after dragging. */
class SnapToEdgeFeature : Feature {
    override val id = MenuSettings.SNAP_TO_EDGE
    override val title = "Snap to edge"
    override val description = "Move the floating button to the nearest side after you drag it."
    override val category = FeatureCategory.MENU
    override val kind = FeatureKind.TOGGLE
    override val defaultEnabled = MenuSettings.SNAP_TO_EDGE_DEFAULT
    override fun checkCompatibility(env: FeatureEnvironment): Compatibility = Compatibility.Supported
    override fun onToggle(env: FeatureEnvironment, enabled: Boolean): FeatureResult = FeatureResult.Ok()
}

class RescanFeature : Feature {
    override val id = "compat.rescan"
    override val title = "Re-scan game"
    override val description = "Read the installed game's version, engine and backend again."
    override val category = FeatureCategory.COMPATIBILITY
    override val kind = FeatureKind.ACTION
    override fun checkCompatibility(env: FeatureEnvironment): Compatibility = Compatibility.Supported
    override fun onAction(env: FeatureEnvironment): FeatureResult {
        env.requestRescan()
        return FeatureResult.Ok()
    }
}

class CopyReportFeature : Feature {
    override val id = "compat.copy_report"
    override val title = "Copy report"
    override val description = "Copy the compatibility report to the clipboard."
    override val category = FeatureCategory.COMPATIBILITY
    override val kind = FeatureKind.ACTION
    override fun checkCompatibility(env: FeatureEnvironment): Compatibility = Compatibility.Supported
    override fun onAction(env: FeatureEnvironment): FeatureResult {
        val cm = env.context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Mod Menu report", env.report.toText()))
        return FeatureResult.Ok("Copied")
    }
}

object SharedFeatures {
    fun standard(): List<Feature> =
        listOf(RescanFeature(), CopyReportFeature(), AutoCollapseFeature(), SnapToEdgeFeature())
}
