package com.modmenu.compatibility

import android.content.Context
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import com.modmenu.core.GameProfile
import com.modmenu.core.GameReport
import com.modmenu.core.ScriptingBackend
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipFile

/**
 * Reads the installed game's APK(s) and reports what is actually there: version, ABIs,
 * whether it is a Unity build, the Unity version and the scripting backend.
 * Nothing is assumed from the game's name or from a hardcoded version.
 */
class GameInspector(context: Context) {
    private val pm: PackageManager = context.applicationContext.packageManager

    fun inspect(profile: GameProfile, packageOverride: String? = null): GameReport {
        val deviceAbis = Build.SUPPORTED_ABIS.toList()
        val candidates =
            if (!packageOverride.isNullOrBlank()) listOf(packageOverride.trim()) else profile.knownPackages

        var found: PackageInfo? = null
        for (name in candidates) {
            found = lookup(name)
            if (found != null) break
        }
        val pkg = found ?: return GameReport(
            profile = profile,
            installed = false,
            deviceAbis = deviceAbis,
            warnings = listOf("Not installed. Looked for: ${candidates.joinToString()}")
        )

        val ai = pkg.applicationInfo
        val paths = ArrayList<String>()
        ai?.sourceDir?.let { paths.add(it) }
        ai?.splitSourceDirs?.let { paths.addAll(it.toList()) }

        val scan = scanApks(paths)
        val warnings = ArrayList<String>(scan.errors)
        if (paths.isEmpty()) warnings.add("Could not locate the game's APK files.")
        if (scan.abis.isNotEmpty() && deviceAbis.none { it in scan.abis }) {
            warnings.add("None of the game's native ABIs (${scan.abis.joinToString()}) match this device (${deviceAbis.joinToString()}).")
        }

        val unityFound = scan.unity || scan.il2cpp || scan.mono
        val isUnity: Boolean? = when {
            unityFound -> true
            paths.isEmpty() || scan.errors.isNotEmpty() -> null
            else -> false
        }
        val backend = when {
            scan.il2cpp && !scan.mono -> ScriptingBackend.IL2CPP
            scan.mono && !scan.il2cpp -> ScriptingBackend.MONO
            scan.il2cpp && scan.mono -> {
                warnings.add("Both IL2CPP and Mono markers were found; backend is ambiguous.")
                ScriptingBackend.UNKNOWN
            }
            isUnity == true -> {
                warnings.add("Unity detected, but no scripting-backend markers were found (data may live in an asset pack).")
                ScriptingBackend.UNKNOWN
            }
            isUnity == false -> ScriptingBackend.NOT_UNITY
            else -> ScriptingBackend.UNKNOWN
        }
        if (isUnity == true && scan.unityVersion == null) warnings.add("Unity version string was not found.")

        return GameReport(
            profile = profile,
            installed = true,
            packageName = pkg.packageName,
            versionName = pkg.versionName,
            versionCode = versionCodeOf(pkg),
            apkAbis = scan.abis.toList(),
            deviceAbis = deviceAbis,
            isUnity = isUnity,
            backend = backend,
            unityVersion = scan.unityVersion,
            apkCount = paths.size,
            warnings = warnings
        )
    }

    @Suppress("DEPRECATION")
    private fun lookup(name: String): PackageInfo? =
        try { pm.getPackageInfo(name, 0) } catch (e: PackageManager.NameNotFoundException) { null }

    @Suppress("DEPRECATION")
    private fun versionCodeOf(p: PackageInfo): Long =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) p.longVersionCode else p.versionCode.toLong()

    private class Scan(
        val abis: Set<String>,
        val unity: Boolean,
        val il2cpp: Boolean,
        val mono: Boolean,
        val unityVersion: String?,
        val errors: List<String>
    )

    private fun scanApks(paths: List<String>): Scan {
        val abis = sortedSetOf<String>()
        val errors = ArrayList<String>()
        var unity = false
        var il2cpp = false
        var mono = false
        var version: String? = null

        for (path in paths) {
            try {
                ZipFile(path).use { zip ->
                    val entries = zip.entries()
                    while (entries.hasMoreElements()) {
                        val e = entries.nextElement()
                        val n = e.name
                        if (n.startsWith("lib/")) {
                            val parts = n.split('/')
                            if (parts.size >= 3) {
                                abis.add(parts[1])
                                val file = parts[2]
                                if (file == "libunity.so") unity = true
                                else if (file == "libil2cpp.so") il2cpp = true
                                else if (file.startsWith("libmono")) mono = true
                            }
                        } else if (n == "assets/bin/Data/Managed/Metadata/global-metadata.dat") {
                            il2cpp = true
                        } else if (n.startsWith("assets/bin/Data/Managed/") && n.endsWith("Assembly-CSharp.dll")) {
                            mono = true
                        } else if (version == null &&
                            (n == "assets/bin/Data/globalgamemanagers" || n == "assets/bin/Data/data.unity3d")
                        ) {
                            version = readUnityVersion(zip, e)
                        }
                    }
                }
            } catch (t: Throwable) {
                errors.add("${File(path).name}: ${t.javaClass.simpleName}: ${t.message}")
            }
        }
        return Scan(abis, unity, il2cpp, mono, version, errors)
    }

    private val versionRegex = Regex("""\d{1,4}\.\d{1,2}\.\d{1,2}[abfp]\d{1,3}""")

    private fun readUnityVersion(zip: ZipFile, entry: ZipEntry): String? {
        zip.getInputStream(entry).use { input ->
            val buf = ByteArray(4096)
            var read = 0
            while (read < buf.size) {
                val n = input.read(buf, read, buf.size - read)
                if (n <= 0) break
                read += n
            }
            return versionRegex.find(String(buf, 0, read, Charsets.ISO_8859_1))?.value
        }
    }
}
