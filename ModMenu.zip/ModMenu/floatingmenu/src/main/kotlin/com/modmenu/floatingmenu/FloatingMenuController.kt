package com.modmenu.floatingmenu

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import com.modmenu.compatibility.GameInspector
import com.modmenu.configuration.ConfigStore
import com.modmenu.configuration.MenuPosition
import com.modmenu.core.CONFIG_KEY_ENABLED
import com.modmenu.core.Compatibility
import com.modmenu.core.Feature
import com.modmenu.core.FeatureCategory
import com.modmenu.core.FeatureConfig
import com.modmenu.core.FeatureEnvironment
import com.modmenu.core.FeatureKind
import com.modmenu.core.FeatureResult
import com.modmenu.core.GameModule
import com.modmenu.core.GameProfile
import com.modmenu.core.GameReport
import com.modmenu.core.MenuSettings
import com.modmenu.resources.R
import kotlin.math.hypot

/**
 * Draws the draggable round button and the collapsible feature panel as overlay windows.
 * Shared by every game; only the GameModule it is given differs.
 */
class FloatingMenuController(
    private val ctx: Context,
    private val module: GameModule,
    private val config: ConfigStore,
    private val onClose: () -> Unit
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val density = ctx.resources.displayMetrics.density
    private val handler = Handler(Looper.getMainLooper())
    private val gameId = module.profile.id
    private val inspector = GameInspector(ctx)
    private val features: List<Feature> = module.createFeatures()
    private val touchSlop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val bubbleSize = dp(56)

    private var report: GameReport = GameReport(module.profile, installed = false)
    private var bubble: View? = null
    private lateinit var bubbleParams: WindowManager.LayoutParams
    private var panel: View? = null
    private var expanded = false
    private var snapAnimator: ValueAnimator? = null
    private val autoCollapse = Runnable { collapse() }

    private val env = object : FeatureEnvironment {
        override val context: Context get() = ctx
        override val profile: GameProfile get() = module.profile
        override val report: GameReport get() = this@FloatingMenuController.report
        override fun configFor(feature: Feature): FeatureConfig = config.forFeature(gameId, feature.id)
        override fun requestRescan() { handler.post { rescan() } }
    }

    // ------------------------------------------------------------------ lifecycle

    fun show() {
        report = scan()
        addBubble()
    }

    fun destroy() {
        handler.removeCallbacksAndMessages(null)
        snapAnimator?.cancel()
        removePanelNow()
        safeRemove(bubble)
        bubble = null
    }

    fun onScreenChanged() {
        if (bubble == null) return
        applySavedPosition()
        updateBubble()
        if (expanded) { removePanelNow(); expand() }
    }

    private fun scan(): GameReport = try {
        inspector.inspect(module.profile, config.getPackageOverride(gameId))
    } catch (t: Throwable) {
        GameReport(module.profile, installed = false, warnings = listOf("Scan failed: ${t.message ?: t.javaClass.simpleName}"))
    }

    private fun rescan() {
        report = scan()
        if (expanded) { removePanelNow(); expand() }
    }

    // ------------------------------------------------------------------ bubble

    private fun addBubble() {
        val v = TextView(ctx).apply {
            text = "M"
            gravity = Gravity.CENTER
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(col(R.color.mm_purple), col(R.color.mm_blue))
            ).apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), 0x55FFFFFF)
            }
            alpha = 0f
            scaleX = 0.6f
            scaleY = 0.6f
        }
        bubbleParams = params(bubbleSize, bubbleSize)
        applySavedPosition()
        v.setOnTouchListener(BubbleTouchListener())
        wm.addView(v, bubbleParams)
        bubble = v
        v.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(220).start()
    }

    private inner class BubbleTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var downX = 0f
        private var downY = 0f
        private var dragging = false

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    snapAnimator?.cancel()
                    startX = bubbleParams.x
                    startY = bubbleParams.y
                    downX = e.rawX
                    downY = e.rawY
                    dragging = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (!dragging && hypot(dx.toDouble(), dy.toDouble()) > touchSlop) {
                        dragging = true
                        if (expanded) collapse()
                    }
                    if (dragging) {
                        val (sw, sh) = screenSize()
                        bubbleParams.x = (startX + dx.toInt()).coerceIn(0, (sw - bubbleSize).coerceAtLeast(0))
                        bubbleParams.y = (startY + dy.toInt()).coerceIn(0, (sh - bubbleSize).coerceAtLeast(0))
                        updateBubble()
                    }
                }
                MotionEvent.ACTION_UP -> if (dragging) finishDrag() else toggle()
                MotionEvent.ACTION_CANCEL -> if (dragging) finishDrag()
                else -> return false
            }
            return true
        }
    }

    private fun finishDrag() {
        val snap = config.forFeature(gameId, MenuSettings.SNAP_TO_EDGE)
            .getBoolean(CONFIG_KEY_ENABLED, MenuSettings.SNAP_TO_EDGE_DEFAULT)
        if (!snap) { savePosition(); return }
        val (sw, _) = screenSize()
        val target = if (bubbleParams.x + bubbleSize / 2 < sw / 2) 0 else (sw - bubbleSize).coerceAtLeast(0)
        snapAnimator = ValueAnimator.ofInt(bubbleParams.x, target).apply {
            duration = 200
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                bubbleParams.x = it.animatedValue as Int
                updateBubble()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) { savePosition() }
            })
            start()
        }
    }

    private fun updateBubble() {
        val b = bubble ?: return
        try { wm.updateViewLayout(b, bubbleParams) } catch (e: IllegalArgumentException) { /* view already removed */ }
    }

    private fun savePosition() {
        val (sw, sh) = screenSize()
        val maxX = (sw - bubbleSize).coerceAtLeast(1)
        val maxY = (sh - bubbleSize).coerceAtLeast(1)
        config.setMenuPosition(gameId, MenuPosition(bubbleParams.x.toFloat() / maxX, bubbleParams.y.toFloat() / maxY))
    }

    private fun applySavedPosition() {
        val p = config.getMenuPosition(gameId)
        val (sw, sh) = screenSize()
        bubbleParams.x = (p.xFraction * (sw - bubbleSize).coerceAtLeast(0)).toInt()
        bubbleParams.y = (p.yFraction * (sh - bubbleSize).coerceAtLeast(0)).toInt()
    }

    // ------------------------------------------------------------------ panel

    private fun toggle() { if (expanded) collapse() else expand() }

    private fun expand() {
        if (expanded) return
        val (sw, sh) = screenSize()
        val width = minOf(dp(320), (sw * 0.88f).toInt())
        val maxHeight = (sh * 0.72f).toInt()
        val view = buildPanel()
        view.measure(
            View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val p = params(width, minOf(view.measuredHeight, maxHeight))
        val rightOfBubble = placePanel(p)
        view.alpha = 0f
        view.scaleX = 0.88f
        view.scaleY = 0.88f
        view.pivotX = if (rightOfBubble) 0f else width.toFloat()
        view.pivotY = dp(28).toFloat()
        wm.addView(view, p)
        panel = view
        expanded = true
        view.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180)
            .setInterpolator(DecelerateInterpolator()).start()
        scheduleAutoCollapse()
    }

    private fun collapse() {
        val v = panel ?: return
        panel = null
        expanded = false
        handler.removeCallbacks(autoCollapse)
        v.animate().alpha(0f).scaleX(0.88f).scaleY(0.88f).setDuration(140)
            .withEndAction { safeRemove(v) }.start()
    }

    private fun removePanelNow() {
        handler.removeCallbacks(autoCollapse)
        panel?.let { it.animate().cancel(); safeRemove(it) }
        panel = null
        expanded = false
    }

    /** Positions the panel beside the bubble, keeping it on screen. Returns true if it sits right of the bubble. */
    private fun placePanel(p: WindowManager.LayoutParams): Boolean {
        val (sw, sh) = screenSize()
        val gap = dp(8)
        val margin = dp(4)
        val right = bubbleParams.x + bubbleSize / 2 < sw / 2
        val x = if (right) bubbleParams.x + bubbleSize + gap else bubbleParams.x - p.width - gap
        p.x = x.coerceIn(margin, (sw - p.width - margin).coerceAtLeast(margin))
        p.y = bubbleParams.y.coerceIn(margin, (sh - p.height - margin).coerceAtLeast(margin))
        return right
    }

    private fun scheduleAutoCollapse() {
        handler.removeCallbacks(autoCollapse)
        val on = config.forFeature(gameId, MenuSettings.AUTO_COLLAPSE)
            .getBoolean(CONFIG_KEY_ENABLED, MenuSettings.AUTO_COLLAPSE_DEFAULT)
        if (on && expanded) handler.postDelayed(autoCollapse, MenuSettings.AUTO_COLLAPSE_DELAY_MS)
    }

    private inner class PanelRoot(context: Context) : LinearLayout(context) {
        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            scheduleAutoCollapse()
            return super.dispatchTouchEvent(ev)
        }
    }

    private fun buildPanel(): View {
        val root = PanelRoot(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(col(R.color.mm_bg), 20, col(R.color.mm_purple_dim))
            setPadding(dp(12), dp(12), dp(12), dp(12))
        }

        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titles = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(label(module.profile.displayName, 16f, col(R.color.mm_text), bold = true))
        titles.addView(label(report.summaryLine(), 11f, statusColor()))
        header.addView(titles, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(iconButton("–") { collapse() })
        header.addView(iconButton("×") { onClose() })
        root.addView(header)

        val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(ctx).apply {
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(list)
        }
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply {
            topMargin = dp(8)
        })

        // Honest empty state: nothing game-modifying is listed until it has been verified.
        val hasGameFeatures = features.any {
            it.category != FeatureCategory.MENU && it.category != FeatureCategory.COMPATIBILITY
        }
        if (!hasGameFeatures) {
            list.addView(sectionHeader("Game features"))
            list.addView(label(
                "None available. No game feature has been verified for this game build yet, so none are shown.",
                12f, col(R.color.mm_text_dim)
            ).apply { setPadding(dp(4), 0, dp(4), dp(8)) })
        }

        val grouped = features.groupBy { it.category }
            .toSortedMap(compareBy<FeatureCategory> { it.ordinal })
        for ((category, items) in grouped) {
            list.addView(sectionHeader(category.title))
            items.forEach { list.addView(buildRow(it)) }
        }
        if (report.warnings.isNotEmpty()) {
            list.addView(sectionHeader("Warnings"))
            report.warnings.forEach { list.addView(label("• $it", 11f, col(R.color.mm_warn)).apply { setPadding(dp(4), 0, dp(4), dp(4)) }) }
        }
        return root
    }

    private fun buildRow(f: Feature): View {
        val compat = try {
            f.checkCompatibility(env)
        } catch (t: Throwable) {
            Compatibility.Unverified("Compatibility check failed: ${t.message ?: t.javaClass.simpleName}")
        }
        val usable = compat is Compatibility.Supported

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(col(R.color.mm_surface), 12)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            alpha = if (usable) 1f else 0.7f
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(6) }
        }
        val top = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val texts = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(f.title, 14f, col(R.color.mm_text), bold = true))
        texts.addView(label(f.description, 11f, col(R.color.mm_text_dim)))
        top.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
            marginEnd = dp(8)
        })

        val status = label("", 11f, col(R.color.mm_text_dim)).apply { visibility = View.GONE }
        when (f.kind) {
            FeatureKind.TOGGLE -> top.addView(buildSwitch(f, usable, status))
            FeatureKind.ACTION -> top.addView(buildActionButton(f, usable, status))
        }
        row.addView(top)

        val warning = when (compat) {
            is Compatibility.Supported -> null
            is Compatibility.Unsupported -> "Unsupported: ${compat.reason}"
            is Compatibility.Unverified -> "Not verified: ${compat.reason}"
        }
        if (warning != null) {
            row.addView(label(warning, 11f, col(R.color.mm_warn)).apply { setPadding(0, dp(6), 0, 0) })
        }
        row.addView(status)
        return row
    }

    private fun buildSwitch(f: Feature, usable: Boolean, status: TextView): View {
        val cfg = env.configFor(f)
        val sw = Switch(ctx)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(col(R.color.mm_purple), col(R.color.mm_text_dim)))
        sw.trackTintList = ColorStateList(states, intArrayOf(withAlpha(col(R.color.mm_purple), 0x66), 0x33FFFFFF))
        sw.isChecked = cfg.getBoolean(CONFIG_KEY_ENABLED, f.defaultEnabled)
        sw.isEnabled = usable
        var reverting = false
        sw.setOnCheckedChangeListener { button, checked ->
            if (reverting) return@setOnCheckedChangeListener
            when (val r = runFeature { f.onToggle(env, checked) }) {
                is FeatureResult.Ok -> {
                    cfg.putBoolean(CONFIG_KEY_ENABLED, checked)
                    showStatus(status, r.message, error = false)
                }
                is FeatureResult.Failed -> {
                    reverting = true
                    button.isChecked = !checked
                    reverting = false
                    showStatus(status, r.message, error = true)
                }
            }
            scheduleAutoCollapse()
        }
        return sw
    }

    private fun buildActionButton(f: Feature, usable: Boolean, status: TextView): View =
        label("Run", 13f, Color.WHITE, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(col(R.color.mm_purple), col(R.color.mm_blue))
            ).apply { cornerRadius = dp(10).toFloat() }
            isEnabled = usable
            alpha = if (usable) 1f else 0.4f
            setOnClickListener {
                when (val r = runFeature { f.onAction(env) }) {
                    is FeatureResult.Ok -> showStatus(status, r.message, error = false)
                    is FeatureResult.Failed -> showStatus(status, r.message, error = true)
                }
                scheduleAutoCollapse()
            }
        }

    private inline fun runFeature(block: () -> FeatureResult): FeatureResult =
        try { block() } catch (t: Throwable) { FeatureResult.Failed(t.message ?: t.javaClass.simpleName) }

    private fun showStatus(tv: TextView, message: String?, error: Boolean) {
        if (message.isNullOrBlank()) { tv.visibility = View.GONE; return }
        tv.text = message
        tv.setTextColor(col(if (error) R.color.mm_error else R.color.mm_ok))
        tv.visibility = View.VISIBLE
    }

    private fun statusColor(): Int = when {
        !report.installed -> col(R.color.mm_error)
        report.backendKnown -> col(R.color.mm_ok)
        else -> col(R.color.mm_warn)
    }

    // ------------------------------------------------------------------ helpers

    private fun dp(v: Int): Int = (v * density).toInt()
    private fun col(id: Int): Int = ctx.getColor(id)
    private fun withAlpha(color: Int, alpha: Int): Int = (color and 0x00FFFFFF) or (alpha shl 24)

    private fun rounded(color: Int, radiusDp: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun label(s: String, sp: Float, color: Int, bold: Boolean = false): TextView = TextView(ctx).apply {
        text = s
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun sectionHeader(s: String): TextView =
        label(s.uppercase(), 11f, col(R.color.mm_purple), bold = true).apply {
            letterSpacing = 0.08f
            setPadding(dp(4), dp(10), 0, dp(6))
        }

    private fun iconButton(symbol: String, onClick: () -> Unit): TextView =
        label(symbol, 20f, col(R.color.mm_text_dim)).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), 0, dp(10), 0)
            setOnClickListener { onClick() }
        }

    @Suppress("DEPRECATION")
    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    @Suppress("DEPRECATION")
    private fun screenSize(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = DisplayMetrics()
            wm.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }

    private fun safeRemove(v: View?) {
        if (v == null) return
        try { wm.removeViewImmediate(v) } catch (e: IllegalArgumentException) { /* already removed */ }
    }
}
