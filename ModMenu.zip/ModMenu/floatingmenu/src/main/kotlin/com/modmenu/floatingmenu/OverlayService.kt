package com.modmenu.floatingmenu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.modmenu.configuration.ConfigStore
import com.modmenu.core.GameRegistry
import com.modmenu.resources.R

/** Foreground service that owns the floating menu. Stops itself on "Stop" or when the menu is closed. */
class OverlayService : Service() {
    private var controller: FloatingMenuController? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // Must call startForeground quickly, even if we are about to stop.
        val module = intent?.getStringExtra(EXTRA_GAME_ID)?.let { GameRegistry.get(it) }
        enterForeground(module?.profile?.displayName ?: "Mod Menu")

        if (intent?.action == ACTION_STOP || module == null || !Settings.canDrawOverlays(this)) {
            stopSelf()
            return START_NOT_STICKY
        }
        controller?.destroy()
        controller = FloatingMenuController(this, module, ConfigStore(this)) { stopSelf() }.also { it.show() }
        return START_NOT_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        controller?.onScreenChanged()
    }

    override fun onDestroy() {
        controller?.destroy()
        controller = null
        super.onDestroy()
    }

    private fun enterForeground(gameName: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Mod Menu overlay", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Mod Menu is showing")
            .setContentText(gameName)
            .setOngoing(true)
            .addAction(0, "Stop", stop)
            .build()
        val type = when {
            Build.VERSION.SDK_INT >= 34 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            Build.VERSION.SDK_INT >= 29 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
            else -> 0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    companion object {
        const val EXTRA_GAME_ID = "game_id"
        private const val ACTION_STOP = "com.modmenu.floatingmenu.STOP"
        private const val CHANNEL_ID = "overlay"
        private const val NOTIFICATION_ID = 1001

        fun start(context: Context, gameId: String) {
            ContextCompat.startForegroundService(
                context,
                Intent(context, OverlayService::class.java).putExtra(EXTRA_GAME_ID, gameId)
            )
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, OverlayService::class.java))
        }
    }
}
